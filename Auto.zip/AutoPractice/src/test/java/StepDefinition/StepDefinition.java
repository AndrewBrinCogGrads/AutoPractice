package StepDefinition;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;

import autoPracticePkg.AutoPractice.BrowserTestLogin;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.Dresses;
import pageObjects.SortByValidate;
import pageObjects.CreateAccounts;
import pageObjects.Register;
import pageObjects.RegisterEmail;
import pageObjects.SelectDress;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.Keys;
//import org.testng.Assert;
import org.openqa.selenium.chrome.ChromeDriver;

public class StepDefinition extends BrowserTestLogin {

	String firstName = "usernameArg";
	String lastName = "lastNameArg"; 
	String email = "customerEmailArguments19@email.com";
	String address = "13 Crescent Avenue";
	String city = "RhodeIsland";
	String state =  "New York";
	int postcode = 20000;
	String country = "United States";
	int mobile = 0441000111;
	String ref = "MyRef@reference.com";
	String passLink = "http://automationpractice.com/index.php?controller=authentication&back=my-account#account-creation";
	
	@Given("^Initialize the chrome browser$")
    public void initialize_the_chrome_browser() throws Throwable {
		driver = initialization();
    }

	
    @When("^click on signin link$")
    public void click_on_signin_link() throws Throwable {
    	   Register rg = new Register(driver);
           rg.registerMethod().click();
    }

    /*
    @When("^select and enter \"([^\"]*)\"$")
    public void select_and_enter() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	RegisterEmail rgEmail = new RegisterEmail(driver);
        rgEmail.Email().sendKeys();
    }
    
    */
 
    @When("^select and enter email address$")
    public void select_and_enter_email_address() throws Throwable {
    	Thread.sleep(4000);
   	    RegisterEmail rgEmail = new RegisterEmail(driver);
   	    rgEmail.Email().clear();
        rgEmail.Email().sendKeys(email);
        
        
    }
	

    @Then("^click on submit button$")
    public void click_on_submit_button() throws Throwable {
    	 RegisterEmail rgEmail = new RegisterEmail(driver);
    	 rgEmail.Submit().click();
    	 Thread.sleep(2000);
    	 if(driver.findElement(By.xpath("//div[@class='alert alert-danger']")).isDisplayed())
    	 {
    		 String er = driver.findElement(By.xpath("//div[@class='alert alert-danger']")).getText();
    		 System.out.println(driver.findElement(By.xpath("//div[@class='alert alert-danger']")).getText()); // take screenshoot
        	 Assert.assertTrue(er , driver.findElement(By.xpath("//div[@class='alert alert-danger']")).isEnabled()); 	 
    	 }
    	 else
    	 {
    		 Assert.assertTrue("Email Accepted", true); 
    	 }
    	
    	 /*
    	 if(driver.getCurrentUrl() == passLink)
    	 {
    		 Assert.assertTrue("email Accepted", true);
    		System.out.println(driver.findElement(By.xpath("//div[@class='alert alert-danger']")).getText());
    	 } 
    	 else if(driver.getCurrentUrl() == "http://automationpractice.com/index.php?controller=authentication&back=my-account")
    	 {
    		 System.out.println(driver.findElement(By.xpath("//div[@class='alert alert-danger']")).getText()); // take screenshoot
        	 Assert.assertTrue("email already created", false); 
        	 
    	 }
    	 */
    }

    @When("^select Title$")
    public void select_title() throws Throwable {
        CreateAccounts ca = new CreateAccounts(driver);
        ca.Title().click();
    }
	
	
    @When("^select and enter FirstName$")
    public void select_and_enter_firstname() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.FirstName().sendKeys(firstName);
    }

    @When("^select and enter LastName$")
    public void select_and_enter_lastname() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.LastName().sendKeys(lastName);
    }

    @When("^select and enter emailAddress$")
    public void select_and_enter_emailaddress() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
    	ca.EmailAddress().clear();
    	ca.EmailAddress().sendKeys(email);
  
    }

    @When("^select and enter password$")
    public void select_and_enter_password() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.Password().sendKeys("password");
    }

    @When("^select day$")
    public void select_day() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.Day().sendKeys("7");
    }

    @When("^select month$")
    public void select_month() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.Month().sendKeys("March");
    }

    @When("^select year$")
    public void select_year() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.Year().sendKeys("1975");
    }

    @When("^select and enter FirstNameTwo$")
    public void select_and_enter_firstnametwo() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
    	ca.FirstNameTwo().clear();
        ca.FirstNameTwo().sendKeys(firstName);
    }

    @When("^select and enter LastNameTwo$")
    public void select_and_enter_lastnametwo() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
    	ca.LastNameTwo().clear();
        ca.LastNameTwo().sendKeys(lastName);
    }

    @When("^select and enter address$")
    public void select_and_enter_address() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.Address().sendKeys(address);
    }

    @When("^select and enter city$")
    public void select_and_enter_city() throws Throwable {
     	CreateAccounts ca = new CreateAccounts(driver);
        ca.City().sendKeys(city);
    }

    @When("^select and enter state$")
    public void select_and_enter_state() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
    	ca.State().click();
        ca.State().sendKeys(state);
    }

    @When("^select and enter postcode$")
    public void select_and_enter_postcode() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.PostCode().sendKeys(String.valueOf(postcode));
    }

    @When("^select and enter country$")
    public void select_and_enter_country() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
    	ca.Country().click();
        ca.Country().sendKeys(country);
    }

    @When("^select and enter mobileNumber$")
    public void select_and_enter_mobilenumber() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.MobileNumber().sendKeys(String.valueOf(mobile));
    }

    @When("^and select and enter reference$")
    public void and_select_and_enter_reference() throws Throwable {
    	CreateAccounts ca = new CreateAccounts(driver);
    	ca.Reference().click();
    	ca.Reference().clear();
        ca.Reference().sendKeys(ref);
        Thread.sleep(1000);
    }
  
    @Then("^click on register button$")
    public void click_on_register_button() throws Throwable {	
    	CreateAccounts ca = new CreateAccounts(driver);
        ca.Submit().click();
    }
    
    @When("^select dresses$")
    public void select_dresses() throws Throwable {
    	Thread.sleep(2000);
    	  Actions a = new Actions(driver);
  		a.moveToElement(driver.findElement(By.cssSelector("#block_top_menu > ul > li:nth-child(2) > a"))).build().perform();
          //d.summerDressMethod().click();
  		Thread.sleep(1000);
  		Dresses d = new Dresses(driver);
  		d.summerDressMethod().click();
    }
       
    @When("^select sort by button$")
    public void select_sort_by_button() throws Throwable {
        SortByValidate srt = new SortByValidate(driver);
        srt.SortByMethod().click();
        Thread.sleep(2000);
        srt.SortByMethod().sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(2000);
        srt.SortByMethod().sendKeys(Keys.ENTER);
      
    }
    
    /*
    @When("^validate grid display$")
    public void validate_grid_display() throws Throwable {
       SortByValidate sd = new SortByValidate(driver);
     //*[@id="center_column"]/ul/li[1]/div/div[2]/div[1]/span[1]
       String itemOne = driver.findElement(By.xpath("//div[text()='$29.98']")).getText().substring(1);
       System.out.println(itemOne);
    }
    */
    
    @When("^select product$")
    public void select_product() throws Throwable {
       SelectDress  sd = new SelectDress(driver);
       sd.selectItem().click();
    }
    
    @When("^change color to blue$")
    public void change_color_to_blue() throws Throwable {
        SelectDress sd = new SelectDress(driver);
        sd.selectColor().click();
    }

    @When("^click on Addcart button$")
    public void click_on_addcart_button() throws Throwable {
    	 SelectDress sd = new SelectDress(driver);
         sd.submitbtn().click();
    }
    
    @When("^click on proceed to checkout button$")
    public void click_on_proceed_to_checkout_button() throws Throwable {
    	SelectDress sd = new SelectDress(driver);
    	Thread.sleep(2000);
    	//System.out.println(driver.findElement(By.cssSelector("#layer_cart_product_quantity")).getText());
        sd.proceedbtn().click();
    }
    /*
    @When("^click on check button$")
    public void click_on_check_button() throws Throwable {
    	SelectDress sd = new SelectDress(driver);
    	Thread.sleep(1000);
        sd.checkout().click();
    }
    */
    
    @When("^validate product information$")
    public void validate_product_information() throws Throwable {
    	SelectDress sd = new SelectDress(driver);
    	Thread.sleep(2000);
    	
		String product = driver.findElement(By.xpath("//a[text()='Printed Summer Dress']")).getText();
		
		System.out.println(product);
		Thread.sleep(2000);

		if (driver.findElement(By.xpath("//a[text()='Printed Summer Dress']")).getText().contains("Printed Summer Dress")) 
		{
			System.out.println(driver.findElement(By.xpath("//a[text()='Printed Summer Dress']")).getText().contains("Printed Summer Dress"));
			System.out.println("Product matches");
			Assert.assertTrue(true);
		} else {
			System.out.println("Product does not match");
			Assert.assertTrue(false);
		}

		if(driver.findElement(By.xpath("//a[text()='Color : Blue, Size : S']")).getText().contains("Color : Blue, Size : S"))
		{
			System.out.println(driver.findElement(By.xpath("//a[text()='Color : Blue, Size : S']")).getText());
			System.out.println("Colour and Size match");
			Assert.assertTrue(true);
		}
		else
		{
			System.out.println("Colour and Size does not match");
			Assert.assertTrue(false);
		}
		
		if (driver.findElement(By.xpath("//input[@size='2']")).getAttribute("value").contains("1")) {
			System.out.println(driver.findElement(By.xpath("//input[@size='2']")).getAttribute("value"));
			System.out.println("Quantity matches");
			Assert.assertTrue(true);
		} else {
			System.out.println("Quantity does not match");
			Assert.assertTrue(false);
		}
		
		String price = driver.findElement(By.xpath("//span[@class='price special-price']")).getText();
		
		if (driver.findElement(By.xpath("//span[@class='price special-price']")).getText().contains("$28.98")) {
			System.out.println("Price does match");
			System.out.println(price);
			Assert.assertTrue(true);
		} else {
			System.out.println("Price does not match");
			Assert.assertTrue(false);
		}
		
		
		
	}
/*    
    @When("^select and click by price$")
    public void select_and_click_by_price() throws Throwable {
    	SortByValidate srt = new SortByValidate(driver);
    	
        srt.Validation();
  
    }
  */ 
    
}