package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CreateAccounts {

	WebDriver driver;

	public CreateAccounts(WebDriver driver) throws InterruptedException {

		Thread.sleep(3000);
		this.driver = driver;

	}

	
	By title = By.xpath("//*[@id=\"id_gender1\"]");
	By firstName = By.xpath("//*[@id=\"customer_firstname\"]");
	By lastName = By.xpath("//*[@id=\'customer_lastname\']");
	By emailAddress = By.xpath("//*[@id=\"email\"]");
	By password = By.xpath("//*[@id=\"passwd\"]");
	By day = By.xpath("//*[@id=\"days\"]");
	By month = By.xpath("//*[@id=\"months\"]");
	By year = By.xpath("//*[@id=\"years\"]");
	By firstNameTwo = By.xpath("//*[@id=\"firstname\"]");
	By lastNameTwo = By.xpath("//*[@id=\"lastname\"]");
	By address = By.xpath("//*[@id=\"address1\"]");
	By city = By.xpath("//*[@id=\"city\"]");
	By state = By.xpath("//*[@id=\"id_state\"]");
	By postcode = By.xpath("//*[@id=\"postcode\"]");
	By country = By.xpath("//*[@id=\"id_country\"]");
	By mobileNumber = By.xpath("//*[@id=\"phone_mobile\"]");
	By reference = By.xpath("//*[@id=\"alias\"]");
	By submit = By.xpath("//*[@id=\"submitAccount\"]");

	public WebElement Title() {

		return driver.findElement(title);
	}

	public WebElement FirstName() {
		return driver.findElement(firstName);
	}

	public WebElement LastName() {
		return driver.findElement(lastName);
	}

	public WebElement EmailAddress() {
		return driver.findElement(emailAddress);
	}

	public WebElement Password() {
		return driver.findElement(password);
	}

	public WebElement Day() {
		return driver.findElement(day);
	}

	public WebElement Month() {
		return driver.findElement(month);
	}

	public WebElement Year() {
		return driver.findElement(year);
	}

	public WebElement FirstNameTwo() {
		return driver.findElement(firstNameTwo);
	}

	public WebElement LastNameTwo() {
		return driver.findElement(lastNameTwo);
	}

	public WebElement Address() {
		return driver.findElement(address);
	}

	public WebElement City() {
		return driver.findElement(city);
	}

	public WebElement State() {
		return driver.findElement(state);
	}

	public WebElement PostCode() {
		return driver.findElement(postcode);
	}

	public WebElement Country() {
		return driver.findElement(country);
	}

	public WebElement MobileNumber() {
		return driver.findElement(mobileNumber);
	}

	public WebElement Reference() {
		return driver.findElement(reference);
	}

	public WebElement Submit() {
		return driver.findElement(submit);
	}
}
