package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;

public class Register {

WebDriver driver;
	
By sign= By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");

	public Register(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public WebElement registerMethod()
	{
		
		return driver.findElement(sign);
	}
	
}
