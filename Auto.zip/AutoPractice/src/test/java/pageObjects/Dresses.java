package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dresses {

	WebDriver driver;

	// By dressMenu= By.cssSelector("#block_top_menu > ul > li:nth-child(2) > a");
	By summerDress = By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/ul/li[3]/a");

	public Dresses(WebDriver driver) throws InterruptedException {
		Thread.sleep(2000);
		this.driver = driver;
	}

	/*
	 * public WebElement dressesMethod() { return driver.findElement(dressMenu); }
	 */

	public WebElement summerDressMethod() {
		return driver.findElement(summerDress);
	}

}
