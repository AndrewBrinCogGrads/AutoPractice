package autoPracticePkg.AutoPractice;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserTestLogin {

	public WebDriver driver;

	public WebDriver initialization() throws IOException {
		Properties prop = new Properties();
		FileInputStream fs = new FileInputStream("C:\\Users\\777389\\JavaFiles\\AutoPractice\\src\\main\\java\\autoPracticePkg\\AutoPractice\\data.properties");
		prop.load(fs);
		String browsername = System.getProperty("browser");
		if (browsername.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\777389\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(prop.getProperty("url"));
			driver.manage().window().maximize();
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		} else if (browsername.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\777389\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.get(prop.getProperty("url"));
			driver.manage().window().maximize();
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		}
		return driver;

	}

}
