package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelectDress {

	WebDriver driver;

	By item = By.cssSelector("#center_column > ul > li.ajax_block_product.col-xs-12.col-sm-6.col-md-4.first-in-line.last-line.first-item-of-tablet-line.first-item-of-mobile-line.last-mobile-line > div > div.right-block > h5 > a");
	By color = By.cssSelector("#color_14");
	By submit = By.cssSelector("#add_to_cart > button");
	By proceed = By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a");
	By checkout = By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]");
	By validateSizeColor = By.cssSelector("#product_5_20_0_172342 > td.cart_description > small:nth-child(3) > a");

	public SelectDress(WebDriver driver) throws InterruptedException {

		this.driver = driver;
		Thread.sleep(500);
	}

	public WebElement selectItem() {
		return driver.findElement(item);
	}

	public WebElement selectColor() {
		return driver.findElement(color);
	}

	public WebElement submitbtn() {
		return driver.findElement(submit);
	}

	public WebElement proceedbtn() {
		return driver.findElement(proceed);
	}

	public WebElement checkout() {
		return driver.findElement(checkout);
	}

	public WebElement CheckSizeAndColor() {
		return driver.findElement(validateSizeColor);
	}
}
