package pageObjects;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegisterEmail {

	WebDriver driver;
	
	public RegisterEmail(WebDriver driver) {
		this.driver = driver;
	
	}

	By email = By.xpath("//*[@id=\"email_create\"]");
	By submit = By.xpath("//*[@id=\"SubmitCreate\"]");

	public WebElement Email() {
		return driver.findElement(email);
	}

	public WebElement Submit() {
		return driver.findElement(submit);
	}
	

}
