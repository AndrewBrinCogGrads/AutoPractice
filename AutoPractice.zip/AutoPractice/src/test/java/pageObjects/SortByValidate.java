package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SortByValidate {

	WebDriver driver;

	By sortBy = By.cssSelector("#selectProductSort");
	By validate = By.cssSelector("#center_column > ul > li.ajax_block_product.col-xs-12.col-sm-6.col-md-4.first-in-line.last-line.first-item-of-tablet-line.first-item-of-mobile-line.last-mobile-line > div > div.right-block > div.content_price > span.price.product-price");

	public SortByValidate(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement SortByMethod() {
		return driver.findElement(sortBy);
	}

	public WebElement ValidateMethod() {
		return driver.findElement(validate);
	}

	public void Validation() {

	}
}
